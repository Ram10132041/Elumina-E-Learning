export interface ScienceData {
    position : number,
    name : string,
    weight : number,
}