import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ScienceData } from './myDatas';
import { Observable } from 'rxjs';
/*import { Observable } from 'rxjs/observable';*/

@Injectable({
  providedIn: 'root'
})
export class GetDataService {

  private newUrl : "/assets/data1.json"; 
  
  constructor(private http: HttpClient) {

  }

  getMyData(){
    return this.http.get(this.newUrl);
  }
}
