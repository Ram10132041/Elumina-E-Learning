import { Component, OnInit } from '@angular/core';
import { GetDataService } from '../get-data.service';
import { HttpClient } from "@angular/common/http";
@Component({
  selector: 'app-view-table',
  templateUrl: './view-table.component.html',
  styleUrls: ['./view-table.component.css']
})
export class ViewTableComponent implements OnInit {

  myData : any = [];

  constructor(public dataSer : GetDataService, private http : HttpClient) { }

  ngOnInit() {
  console.log("Hello");
  this.dataSer.getMyData().subscribe(data => this.myData = data)

  }

}
